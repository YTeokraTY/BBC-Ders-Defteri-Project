import tkinter as tk
from tkinter import messagebox, simpledialog, ttk, Menu
import json
import os
from datetime import datetime

USERS_DOSYA = "users.json"
DERS_PROGRAMI_DOSYA = "ders_programi.json"
ders_programi = {}

# --- Kullanıcı işlemleri ---
def kullanicilari_yukle():
    if os.path.exists(USERS_DOSYA):
        with open(USERS_DOSYA, "r") as f:
            return json.load(f)
    else:
        return {}

def kullanicilari_kaydet(kullanicilar):
    with open(USERS_DOSYA, "w") as f:
        json.dump(kullanicilar, f, indent=4)

# --- Ders programı işlemleri ---
def varsayilan_ders_programini_yukle():
    global ders_programi
    ders_programi = {
        "Pazartesi": ["Matematik 09:00-10:30", "Fizik 11:00-12:30"],
        "Salı": ["Kimya 10:00-11:30", "Beden Eğitimi 14:00-15:00"],
        "Çarşamba": ["Tarih 09:00-10:30", "Edebiyat 11:00-12:30"],
        "Perşembe": ["Biyoloji 10:00-11:30"],
        "Cuma": ["Matematik 09:00-10:30", "Felsefe 13:00-14:30"],
    }

def ders_programini_kaydet():
    with open(DERS_PROGRAMI_DOSYA, "w", encoding="utf-8") as f:
        json.dump(ders_programi, f, ensure_ascii=False, indent=4)

def ders_programini_yukle():
    global ders_programi
    if os.path.exists(DERS_PROGRAMI_DOSYA):
        with open(DERS_PROGRAMI_DOSYA, "r", encoding="utf-8") as f:
            ders_programi = json.load(f)

def ders_programini_goster():
    ders_programini_yukle()
    metin = ""
    for gun, dersler in ders_programi.items():
        metin += f"{gun}:\n"
        for ders in dersler:
            metin += f"  - {ders}\n"
        metin += "\n"
    messagebox.showinfo("Ders Programı", metin)

def ders_programi_girisi():
    global ders_programi
    gunler = ["Pazartesi", "Salı", "Çarşamba", "Perşembe", "Cuma"]
    max_ders = 8  # Her gün için maksimum ders sayısı

    pencere = tk.Toplevel()
    pencere.title("Ders Programı Girişi")
    pencere.geometry("1100x400")
    pencere.grab_set()

    entries = {}
    # Başlıklar
    tk.Label(pencere, text="Gün / Ders", font=("Arial", 11, "bold")).grid(row=0, column=0, padx=8, pady=4)
    for d in range(1, max_ders+1):
        tk.Label(pencere, text=f"{d}. Ders", font=("Arial", 11, "bold")).grid(row=0, column=d, padx=8, pady=4)

    # Satırlar
    for i, gun in enumerate(gunler):
        tk.Label(pencere, text=gun, font=("Arial", 11)).grid(row=i+1, column=0, padx=8, pady=4)
        entries[gun] = []
        for j in range(max_ders):
            e = tk.Entry(pencere, width=22)
            e.grid(row=i+1, column=j+1, padx=4, pady=4)
            entries[gun].append(e)
    
    def kaydet():
        yeni_program = {}
        for gun in gunler:
            dersler = []
            for entry in entries[gun]:
                val = entry.get().strip()
                if val:
                    dersler.append(val)
            yeni_program[gun] = dersler
        global ders_programi
        ders_programi = yeni_program
        ders_programini_kaydet()
        pencere.destroy()
        messagebox.showinfo("Başarılı", "Ders programı kaydedildi.")

    tk.Button(pencere, text="Kaydet", command=kaydet, bg="#27ae60", fg="white", font=("Arial", 11, "bold")).grid(row=len(gunler)+2, column=0, columnspan=max_ders+1, pady=12)

# ...devamı aynı...

# --- Ödev işlemleri ---
DURUMLAR = ["Yapılmadı", "Yapılıyor", "Tamamlandı"]
ONCELIKLER = ["Düşük", "Orta", "Yüksek"]

class AnaUygulama:
    def __init__(self, kullanici_adi):
        self.kullanici = kullanici_adi
        self.odevler_dosya = f"{self.kullanici}_odevler.json"
        self.odevler = []

        self.pencere = tk.Tk()
        self.pencere.title(f"BBC Ders Defteri - Kullanıcı: {self.kullanici}")
        self.pencere.geometry("900x550")
        self.pencere.configure(bg="#2c3e50")

        self.menubar_olustur()
        self.baslik_olustur()
        self.butonlar_olustur()
        self.treeview_olustur()
        self.sag_tik_menu_olustur()

        self.dosyadan_odevleri_yukle()
        self.liste_odevler_guncel()

        self.pencere.after(100, self.program_baslangici)
        self.pencere.mainloop()

    def menubar_olustur(self):
        menubar = tk.Menu(self.pencere)
        dosya_menu = tk.Menu(menubar, tearoff=0)
        dosya_menu.add_command(label="Çıkış", command=self.pencere.destroy)
        menubar.add_cascade(label="Dosya", menu=dosya_menu)

        yardim_menu = tk.Menu(menubar, tearoff=0)
        yardim_menu.add_command(label="Hakkında", command=self.hakkinda_goster)
        menubar.add_cascade(label="Yardım", menu=yardim_menu)

        self.pencere.config(menu=menubar)

    def baslik_olustur(self):
        baslik = tk.Label(self.pencere, text="Ders Programı ve Ödev Takip", font=("Helvetica", 22, "bold"),
                          bg="#2c3e50", fg="white")
        baslik.pack(pady=15)

    def butonlar_olustur(self):
        frame_butonlar = tk.Frame(self.pencere, bg="#2c3e50")
        frame_butonlar.pack(pady=10)

        btn_ders = tk.Button(frame_butonlar, text="📅 Ders Programını Göster", command=ders_programini_goster,
                             bg="#2980b9", fg="white", font=("Helvetica", 13, "bold"),
                             padx=20, pady=8, relief="raised", bd=3)
        btn_ders.grid(row=0, column=0, padx=12)

        btn_odev_ekle = tk.Button(frame_butonlar, text="➕ Ödev Ekle", command=self.odev_ekle,
                                  bg="#27ae60", fg="white", font=("Helvetica", 13, "bold"),
                                  padx=20, pady=8, relief="raised", bd=3)
        btn_odev_ekle.grid(row=0, column=1, padx=12)

        btn_odev_sil = tk.Button(frame_butonlar, text="❌ Seçili Ödevi Sil", command=self.odev_sil,
                                 bg="#c0392b", fg="white", font=("Helvetica", 13, "bold"),
                                 padx=20, pady=8, relief="raised", bd=3)
        btn_odev_sil.grid(row=0, column=2, padx=12)

    def treeview_olustur(self):
        frame_tree = tk.Frame(self.pencere)
        frame_tree.pack(expand=True, fill="both", padx=20, pady=10)

        columns = ("#", "Ders", "Konu", "Teslim Tarihi", "Öncelik", "Durum")
        self.tree = ttk.Treeview(frame_tree, columns=columns, show="headings", selectmode="browse")

        style = ttk.Style()
        style.theme_use("default")
        style.configure("Treeview",
                        background="#ecf0f1",
                        foreground="black",
                        rowheight=26,
                        fieldbackground="#ecf0f1",
                        font=("Helvetica", 12))
        style.map('Treeview', background=[('selected', '#3498db')])

        style.configure("Treeview.Heading", font=("Helvetica", 14, "bold"))

        self.tree.tag_configure('oddrow', background="#d6dbf5")
        self.tree.tag_configure('evenrow', background="#f8f8f8")
        self.tree.tag_configure('gecmis', background="#f5c6c6")  # Kırmızı geçmiş teslim tarihi
        self.tree.tag_configure('tamamlandi', background="#a6d8a8")  # Yeşil tamamlandı
        self.tree.tag_configure('oncelikli', background="#f7dc6f")  # Sarı öncelikli

        for col in columns:
            self.tree.heading(col, text=col)
            self.tree.column(col, anchor="center", width=130)

        self.tree.pack(expand=True, fill="both")

    def sag_tik_menu_olustur(self):
        self.sag_menu = tk.Menu(self.pencere, tearoff=0)
        self.sag_menu.add_command(label="Ödevi Düzenle ✏️", command=self.odev_duzenle)
        self.sag_menu.add_command(label="Ödevi Sil 🗑️", command=self.odev_sil)

        self.tree.bind("<Button-3>", self.sag_tik_menu)

    def sag_tik_menu(self, event):
        try:
            self.tree.selection_set(self.tree.identify_row(event.y))
            self.sag_menu.post(event.x_root, event.y_root)
        finally:
            self.sag_menu.grab_release()

    def dosyadan_odevleri_yukle(self):
        if os.path.exists(self.odevler_dosya):
            with open(self.odevler_dosya, "r") as f:
                self.odevler = json.load(f)
        else:
            self.odevler = []

    def dosyaya_odevleri_kaydet(self):
        with open(self.odevler_dosya, "w") as f:
            json.dump(self.odevler, f, indent=4)

    def odev_ekle(self):
        ekle_pencere = tk.Toplevel(self.pencere)
        ekle_pencere.title("Ödev Ekle")
        ekle_pencere.geometry("350x350")
        ekle_pencere.grab_set()

        tk.Label(ekle_pencere, text="Ders adı:").pack(pady=5)
        ders_var = tk.StringVar()
        tk.Entry(ekle_pencere, textvariable=ders_var).pack()

        tk.Label(ekle_pencere, text="Konu:").pack(pady=5)
        konu_var = tk.StringVar()
        tk.Entry(ekle_pencere, textvariable=konu_var).pack()

        tk.Label(ekle_pencere, text="Teslim tarihi (YYYY-AA-GG):").pack(pady=5)
        teslim_var = tk.StringVar()
        tk.Entry(ekle_pencere, textvariable=teslim_var).pack()

        tk.Label(ekle_pencere, text="Öncelik:").pack(pady=5)
        oncelik_var = tk.StringVar(value="Orta")
        oncelik_combo = ttk.Combobox(ekle_pencere, textvariable=oncelik_var, values=ONCELIKLER, state="readonly")
        oncelik_combo.pack()

        tk.Label(ekle_pencere, text="Durum:").pack(pady=5)
        durum_var = tk.StringVar(value="Yapılmadı")
        durum_combo = ttk.Combobox(ekle_pencere, textvariable=durum_var, values=DURUMLAR, state="readonly")
        durum_combo.pack()

        def kaydet():
            ders = ders_var.get().strip()
            konu = konu_var.get().strip()
            teslim = teslim_var.get().strip()
            oncelik = oncelik_var.get()
            durum = durum_var.get()

            if not ders or not konu or not teslim:
                messagebox.showwarning("Uyarı", "Tüm alanları doldurun.", parent=ekle_pencere)
                return
            try:
                datetime.strptime(teslim, "%Y-%m-%d")
            except ValueError:
                messagebox.showerror("Hata", "Tarih formatı yanlış! YYYY-AA-GG şeklinde olmalı.", parent=ekle_pencere)
                return

            odev = {
                "ders": ders,
                "konu": konu,
                "teslim_tarihi": teslim,
                "oncelik": oncelik,
                "durum": durum
            }
            self.odevler.append(odev)
            self.odevler.sort(key=lambda x: x["teslim_tarihi"])
            self.dosyaya_odevleri_kaydet()
            self.liste_odevler_guncel()
            ekle_pencere.destroy()

        tk.Button(ekle_pencere, text="Kaydet", command=kaydet, bg="#27ae60", fg="white").pack(pady=15)

    def odev_sil(self):
        secim = self.tree.selection()
        if not secim:
            messagebox.showwarning("Uyarı", "Lütfen silmek için bir ödev seçin.")
            return
        cevap = messagebox.askyesno("Onay", "Seçili ödevi silmek istediğinize emin misiniz?")
        if cevap:
            secilen_index = int(self.tree.item(secim)["values"][0]) - 1
            del self.odevler[secilen_index]
            self.dosyaya_odevleri_kaydet()
            self.liste_odevler_guncel()

    def odev_duzenle(self):
        secim = self.tree.selection()
        if not secim:
            messagebox.showwarning("Uyarı", "Lütfen düzenlemek için bir ödev seçin.")
            return
        secilen_index = int(self.tree.item(secim)["values"][0]) - 1
        odev = self.odevler[secilen_index]

        # Test sorusu gibi şıklarla seçim için yeni pencere
        duzen_pencere = tk.Toplevel(self.pencere)
        duzen_pencere.title("Ödev Düzenle")
        duzen_pencere.geometry("350x350")
        duzen_pencere.grab_set()

        tk.Label(duzen_pencere, text="Ders adı:").pack(pady=5)
        ders_var = tk.StringVar(value=odev["ders"])
        tk.Entry(duzen_pencere, textvariable=ders_var).pack()

        tk.Label(duzen_pencere, text="Konu:").pack(pady=5)
        konu_var = tk.StringVar(value=odev["konu"])
        tk.Entry(duzen_pencere, textvariable=konu_var).pack()

        tk.Label(duzen_pencere, text="Teslim tarihi (YYYY-AA-GG):").pack(pady=5)
        teslim_var = tk.StringVar(value=odev["teslim_tarihi"])
        tk.Entry(duzen_pencere, textvariable=teslim_var).pack()

        tk.Label(duzen_pencere, text="Öncelik:").pack(pady=5)
        oncelik_var = tk.StringVar(value=odev["oncelik"])
        oncelik_combo = ttk.Combobox(duzen_pencere, textvariable=oncelik_var, values=ONCELIKLER, state="readonly")
        oncelik_combo.pack()

        tk.Label(duzen_pencere, text="Durum:").pack(pady=5)
        durum_var = tk.StringVar(value=odev["durum"])
        durum_combo = ttk.Combobox(duzen_pencere, textvariable=durum_var, values=DURUMLAR, state="readonly")
        durum_combo.pack()

        def kaydet():
            try:
                datetime.strptime(teslim_var.get(), "%Y-%m-%d")
            except ValueError:
                messagebox.showerror("Hata", "Tarih formatı yanlış! YYYY-AA-GG şeklinde olmalı.")
                return
            self.odevler[secilen_index] = {
                "ders": ders_var.get(),
                "konu": konu_var.get(),
                "teslim_tarihi": teslim_var.get(),
                "oncelik": oncelik_var.get(),
                "durum": durum_var.get()
            }
            self.odevler.sort(key=lambda x: x["teslim_tarihi"])
            self.dosyaya_odevleri_kaydet()
            self.liste_odevler_guncel()
            duzen_pencere.destroy()

        tk.Button(duzen_pencere, text="Kaydet", command=kaydet, bg="#27ae60", fg="white").pack(pady=15)

    def liste_odevler_guncel(self):
        self.tree.delete(*self.tree.get_children())
        bugun = datetime.today()
        for idx, odev in enumerate(self.odevler, start=1):
            teslim_tarihi = datetime.strptime(odev["teslim_tarihi"], "%Y-%m-%d")
            if odev["durum"] == "Tamamlandı":
                tag = "tamamlandi"
            elif teslim_tarihi < bugun:
                tag = "gecmis"
            elif odev["oncelik"] == "Yüksek":
                tag = "oncelikli"
            elif idx % 2 == 0:
                tag = "evenrow"
            else:
                tag = "oddrow"

            self.tree.insert("", "end",
                             values=(idx, odev["ders"], odev["konu"], odev["teslim_tarihi"], odev["oncelik"], odev["durum"]),
                             tags=(tag,))

    def program_baslangici(self):
        cevap = messagebox.askyesno(
            "Ders Programı",
            "Ders programınızı elle girmek ister misiniz?\nHayır derseniz varsayılan program yüklenecek."
        )
        if cevap:
            ders_programi_girisi()
        else:
            varsayilan_ders_programini_yukle()

    def hakkinda_goster(self):
        messagebox.showinfo("Hakkında", "Ders Programı ve Ödev Takip Uygulaması\n2025 © Ayaz")

# --- Giriş ekranı ---
class GirisEkrani:
    def __init__(self, master):
        self.master = master
        master.title("Giriş Yap / Kayıt Ol")
        master.geometry("300x200")
        master.resizable(False, False)

        self.kullanicilar = kullanicilari_yukle()

        self.lbl_kullanici = tk.Label(master, text="Kullanıcı Adı:")
        self.lbl_kullanici.pack(pady=(20,5))
        self.ent_kullanici = tk.Entry(master)
        self.ent_kullanici.pack()

        self.lbl_sifre = tk.Label(master, text="Şifre:")
        self.lbl_sifre.pack(pady=(10,5))
        self.ent_sifre = tk.Entry(master, show="*")
        self.ent_sifre.pack()

        self.btn_giris = tk.Button(master, text="Giriş Yap", command=self.giris_yap)
        self.btn_giris.pack(pady=(15,5))

        self.btn_kayit = tk.Button(master, text="Kayıt Ol", command=self.kayit_ol)
        self.btn_kayit.pack()

    def giris_yap(self):
        kullanici = self.ent_kullanici.get().strip()
        sifre = self.ent_sifre.get().strip()

        if kullanici == "" or sifre == "":
            messagebox.showwarning("Uyarı", "Kullanıcı adı ve şifre boş olamaz.")
            return

        if kullanici in self.kullanicilar and self.kullanicilar[kullanici] == sifre:
            messagebox.showinfo("Başarılı", f"Hoşgeldin, {kullanici}!")
            self.master.destroy()
            AnaUygulama(kullanici)
        else:
            messagebox.showerror("Hata", "Kullanıcı adı veya şifre yanlış.")

    def kayit_ol(self):
        kullanici = self.ent_kullanici.get().strip()
        sifre = self.ent_sifre.get().strip()

        if kullanici == "" or sifre == "":
            messagebox.showwarning("Uyarı", "Kullanıcı adı ve şifre boş olamaz.")
            return

        if kullanici in self.kullanicilar:
            messagebox.showerror("Hata", "Bu kullanıcı adı zaten kayıtlı.")
            return

        self.kullanicilar[kullanici] = sifre
        kullanicilari_kaydet(self.kullanicilar)
        messagebox.showinfo("Başarılı", "Kayıt başarılı! Şimdi giriş yapabilirsiniz.")

# --- Program başlangıcı ---
if __name__ == "__main__":
    root = tk.Tk()
    app = GirisEkrani(root)
    root.mainloop()
